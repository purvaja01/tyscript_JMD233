//@ts-nocheck
var _a;
function removeRow(r) {
    var tableRow = r.closest("tr");
    if (tableRow) {
        var table = document.getElementById("setit");
        table.deleteRow(tableRow.rowIndex);
    }
}
function searchTasks() {
    var searchInput = document.getElementById("search-input");
    if (searchInput) {
        var taskList = document.querySelectorAll(".task-name");
        var searchInputValue_1 = searchInput.value.toLowerCase();
        taskList.forEach(function (task) {
            var _a;
            var taskName = (_a = task.textContent) === null || _a === void 0 ? void 0 : _a.toLowerCase();
            var parentRow = task.parentElement;
            if (taskName && parentRow) {
                if (taskName.includes(searchInputValue_1)) {
                    parentRow.style.display = "table-row";
                }
                else {
                    parentRow.style.display = "none";
                }
            }
        });
    }
}
function addbtn() {
    var _a;
    var taskInput = document.getElementById("task-input");
    if (taskInput) {
        var taskInputValue_1 = taskInput.value.trim();
        if (taskInputValue_1 === "") {
            alert("You must write something!");
        }
        else {
            var taskList = document.querySelectorAll(".task-name");
            var taskAlreadyExists_1 = false;
            taskList.forEach(function (task) {
                var _a;
                if (((_a = task.textContent) === null || _a === void 0 ? void 0 : _a.toLowerCase()) === taskInputValue_1.toLowerCase()) {
                    taskAlreadyExists_1 = true;
                }
            });
            if (taskAlreadyExists_1) {
                alert("Task already exists!");
            }
            else {
                var newListElement = document.createElement("li");
                var newRow = document.createElement("tr");
                newRow.innerHTML = "\n            <td><label><input type=\"checkbox\" class=\"task-checkbox\"></label></td>\n            <td class=\"task-name\">".concat(taskInputValue_1, "</td>\n            <td>\n              <select class=\"status-select\">\n                <option value=\"todo\">Todo</option>\n                <option value=\"in-progress\">In Progress</option>\n                <option value=\"completed\">Completed</option>\n              </select>\n            </td>\n            <td><button onclick=\"removeRow(this)\">x</button></td>");
                var table = document.querySelector(".setit");
                if (table) {
                    table.appendChild(newRow);
                }
                newListElement.appendChild(table);
                var ul = document.getElementById("myUL");
                if (ul) {
                    ul.appendChild(newListElement);
                }
                taskInput.value = "";
                var checkboxes = newRow.getElementsByClassName("task-checkbox");
                var statusSelect_1 = newRow.getElementsByClassName("status-select")[0];
                (_a = checkboxes[0]) === null || _a === void 0 ? void 0 : _a.addEventListener("change", function () {
                    var tr = this.closest("tr");
                    tr === null || tr === void 0 ? void 0 : tr.classList.toggle("checked", this.checked);
                    if (this.checked) {
                        statusSelect_1.value = "completed";
                    }
                    else {
                        statusSelect_1.value = "todo";
                    }
                });
                statusSelect_1 === null || statusSelect_1 === void 0 ? void 0 : statusSelect_1.addEventListener("change", function () {
                    var tr = this.closest("tr");
                    tr === null || tr === void 0 ? void 0 : tr.classList.toggle("checked", this.value === "completed");
                });
            }
        }
    }
}
// Attach the 'searchTasks' function as an event listener
(_a = document.getElementById("search-input")) === null || _a === void 0 ? void 0 : _a.addEventListener("input", searchTasks);
