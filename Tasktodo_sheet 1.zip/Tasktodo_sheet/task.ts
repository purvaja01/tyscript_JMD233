//@ts-nocheck

function removeRow(r: HTMLElement) {
    const tableRow = r.closest("tr") as HTMLTableRowElement;
  if (tableRow) {
    const table = document.getElementById("setit") as HTMLTableElement;
    table.deleteRow(tableRow.rowIndex);
  }
}
  
  function searchTasks() {
    const searchInput = document.getElementById("search-input") as HTMLInputElement;
    if (searchInput) {
      const taskList = document.querySelectorAll(".task-name");
  
      const searchInputValue = searchInput.value.toLowerCase();
  
      taskList.forEach(function (task) {
        const taskName = task.textContent?.toLowerCase();
        const parentRow = task.parentElement;
  
        if (taskName && parentRow) {
          if (taskName.includes(searchInputValue)) {
            parentRow.style.display = "table-row";
          } else {
            parentRow.style.display = "none";
          }
        }
      });
    }
  }
  
  function addbtn() {
    const taskInput = document.getElementById("task-input") as HTMLInputElement;
    if (taskInput) {
      const taskInputValue = taskInput.value.trim();
  
      if (taskInputValue === "") {
        alert("You must write something!");
      } else {
        const taskList = document.querySelectorAll(".task-name");
  
        let taskAlreadyExists = false;
  
        taskList.forEach(function (task) {
          if (task.textContent?.toLowerCase() === taskInputValue.toLowerCase()) {
            taskAlreadyExists = true;
          }
        });
  
        if (taskAlreadyExists) {
          alert("Task already exists!");
        } else {
          const newListElement = document.createElement("li");
          const newRow = document.createElement("tr");
  
          newRow.innerHTML = `
            <td><label><input type="checkbox" class="task-checkbox"></label></td>
            <td class="task-name">${taskInputValue}</td>
            <td>
              <select class="status-select">
                <option value="todo">Todo</option>
                <option value="in-progress">In Progress</option>
                <option value="completed">Completed</option>
              </select>
            </td>
            <td><button onclick="removeRow()">x</button></td>`;
  
          const table = document.querySelector(".setit") as HTMLTableElement;
          if (table) {
            table.appendChild(newRow);
          }
  
          newListElement.appendChild(table);
          const ul = document.getElementById("myUL");
          if (ul) {
            ul.appendChild(newListElement);
          }
          taskInput.value = "";
  
          const checkboxes = newRow.getElementsByClassName("task-checkbox") as HTMLCollectionOf<HTMLInputElement>;
          const statusSelect = newRow.getElementsByClassName("status-select")[0] as HTMLSelectElement;
  
          checkboxes[0]?.addEventListener("change", function () {
            const tr = this.closest("tr");
            tr?.classList.toggle("checked", this.checked);
            if (this.checked) {
              statusSelect.value = "completed";
            } else {
              statusSelect.value = "todo";
            }
          });
  
          statusSelect?.addEventListener("change", function () {
            const tr = this.closest("tr");
            tr?.classList.toggle("checked", this.value === "completed");
          });
        }
      }
    }
  }
  
  // Attach the 'searchTasks' function as an event listener
  document.getElementById("search-input")?.addEventListener("input", searchTasks);
  